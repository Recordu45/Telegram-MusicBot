# Telegram Music Bot (Minimal)

This is a minimal working Telegram music bot built with Pyrogram and PyTgCalls.

## Deploy to Render

[![Deploy to Render](https://render.com/images/deploy-to-render-button.svg)](https://render.com/deploy?repo=https://github.com/Recordu45/Telegram-MusicBot)

### Required Environment Variables:
- `API_ID`
- `API_HASH`
- `BOT_TOKEN`
- `STRING_SESSION`