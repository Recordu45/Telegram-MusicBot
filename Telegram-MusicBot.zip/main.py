import os
from pyrogram import Client
from pytgcalls import PyTgCalls

api_id = int(os.getenv("API_ID"))
api_hash = os.getenv("API_HASH")
bot_token = os.getenv("BOT_TOKEN")
string_session = os.getenv("STRING_SESSION")

app = Client(name="music_bot", api_id=api_id, api_hash=api_hash, bot_token=bot_token, session_string=string_session)
pytgcalls = PyTgCalls(app)

@app.on_message()
async def start(client, message):
    await message.reply("Bot is working!")

app.start()
print("Bot is running...")
pytgcalls.start()
app.idle()